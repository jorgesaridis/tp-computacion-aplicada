history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ls
ls -ahl
shutdown 0
exec /sbin/init 
clear
exec /sbin/init
ls -ahl
shutdown 0
shutdown 0
cat /var/log/boot
cd /var/log/
ls -ahl
clear
ls -ahl | more
qclear
cc
clear
dmesg | less
}
clear
dmesg | grep -i error
cd /
nano /etc/fstab 
vi /etc/fstab 
clear
shutdown 0
dmesg | grep -i error
reboot
reboot
hostnamectl set-hostname TPServer
cat /etc/hosts
cat /etc/hostname 
vi /etc/hosts
vi /etc/hosts
vi /etc/hosts
vi /etc/hosts
hostnamectl 
cat /etc/hostname 
apt update
shutdown 0
ip addr
ip link set enp1s0 up
ip addr
apt update
ping www.google.com
shutdown 0
apt update
ip addr
cat /etc/network/interfaces
vi /etc/network/interfaces
cat /etc/network/interfaces
reboot
apt update
ip addr
cat /etc/network/interfaces
ping www.google.com
apt update
cat /etc/resolv.conf 
vi /etc/resolv.conf 
vi /etc/resolv.conf 
cat /etc/resolv.conf 
apt update
shutdown 0
apt update
cat /etc/resolv.conf 
env | grep -i proxy
rm -rf /var/lib/apt/lists/*
apt clean
apt update
cat /etc/environment 
cd /etc/apt/apt.conf.d/
ls
ls -ahl
shutdown 0
cd /etc/apt/apt.conf.d/
ls -ahl
apt update
cd ..
ls -ahl
cat ./sources.list
cat ./sources.list.d/
cd ./sources.list.d/
ls -ahl
cd ..
shutdown 0
ping www.google.com
apt update
cd /etc/apt
ls -ahl
cat ./sources.list
cp ./sources.list ./sources.list.orig
vi ./sources.list
cat ./sources.list
apt update
cd /var/log/
ls -ahl
cat syslog
cat syslog | grep -i Failed
cat /etc/fstab 
cd /home/
ls
cd /
lsblk 
lsblk --help
cat /etc/fstab 
apt install nano
nano /etc/fstab
clear
logout
nano /etc/fstab
shutdown 0
nano /etc/fstab
nano /etc/fstab
ps -A
ps -A | grep vim
ps -A | grep 552
nano /etc/fstab
cat /etc/fstab 
reboot
cat syslog | grep -i Failed
cat /var/log/syslog | grep -i Failed
lsblk -f
cat /etc/fstab 
journalctl -xeu dev-sdb1.mount
cat /etc/fstab 
nano /etc/fstab 
cat /etc/fstab 
reboot
cat /var/log/syslog | grep -i Failed
cd /home/
ls
cat ./compartido/
cd ./compartido/
ls
cat ./arch1
cat ./arch2
cat ./dir1/
ls -ahl
cat ./hola 
cd ./dir1/
ls -ahl
cd /
apt update
apt upgrade
shutdown 0
apt update && apt install spice-vdagent
reboot
shutdown 0
nano /etc/apt/sources.list
apt update
apt update
nano /etc/apt/sources.list
apt update
nano /etc/apt/sources.list
apt update
apt full-upgrade
apt-get update
apt full-upgrade
reboot
lsb_release -a
cat /etc/debian_version 
apt-cache search openssh-server
apt install openssh-server
apt-cache show openssh-server
apt-cache show openssh-server
ls -ahl
phd
pwd
mkdir material
tar xvf ./Material_Adicional_TPVMCA.tar.gz ./material
ls -ahl
tar -xvzf ./Material_Adicional_TPVMCA.tar.gz -C ./material/
ls -ahl
cd ./material/
ls -ahl
cd ./Material_Adicional_TPVMCA/
ls -ahl
cd ..
cd ..
mv ./material/Material_Adicional_TPVMCA/ .
ls -ahl
cd ./material/
ls
cd ..
rm ./material/
rm -f ./material/
rmdir ./material/
ls -ahl
cd ./Material_Adicional_TPVMCA/
ls -ahl
cat ./clave_privada.txt 
cat ./clave_publica.pub 
cd /
nano /etc/ssh/ssh_config
systemctl enable ssh
systemctl status ssh
nano /etc/ssh/ssh_config
cd /root/Material_Adicional_TPVMCA/
ls -ahl
cat ./clave_privada.txt 
ls -ahl
nano /etc/ssh/ssh_config
systemctl restart ssh
nano /etc/ssh/ssh_config
systemctl restart ssh
shutdown 0
cd /root/
ls -ahl
exit
exit
nano /etc/ssh/ssh_config
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl status ssh
systemctl start ssh
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
cd /
ls -ahl
cd /root/
ls -ahl
stat -c "%a %n" .
stat -c "%a %n" ./.ssh/
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
nano /etc/ssh/ssh_config
nano /etc/ssh/ssh_config
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
cd /var/log/
ls -ahl
cat ./auth.log
ssh root@localhost
nano /etc/ssh/ssh_config
nano /etc/ssh/ssh_config
nano /etc/ssh/sshd_config
systemctl stop ssh
systemctl start ssh
shutdown 0
cd /root/Material_Adicional_TPVMCA/
ls -ahl
shutdown 0
exit
exit
exit
cd /root/.ssh/
ls -ahl
cd ..
ls -ahl
cd ./Material_Adicional_TPVMCA/
ls -ahl
cp ./clave_publica.pub ../.ssh/clave_root.pub
cd ../.ssh/
ls -ahl
ls -ahl
./clave_root.pub >> authorized_keys
cat ./clave_root.pub >> authorized_keys
ls -ahl
cat ./authorized_keys 
cd /etc/ssh/
ls -ahl
nano ./sshd_config
systemctl stop ssh
systemctl start ssh
nano ./sshd_config
systemctl status sshd
systemctl restart sshd
apt update && apt upgrade -y
cd /root/
apt install apache2 apache2-utils -y
apt install php libapache2-mod-php php-mysql -y
systemctl restart apache2
echo "<?php phpinfo(); ?>" | tee /var/www/html/info.php
cd ./Material_Adicional_TPVMCA/
ls -ahl
cp ./index.php /var/www/html/
cp ./logo.png /var/www/html/
cd /var/www/html/
ls -ahl
cat ./index.php 
cd /root/Material_Adicional_TPVMCA/
ls -ahl
cat ./db.sql 
apt install mariadb-server-y
apt install mariadb-server -y
mariadb -u root
systemctl enable mariadb.service
systemctl status mariadb.service
cat ./db.sql 
mariadb -u root
mariadb -u root < ./db.sql 
mariadb -u root
cd ..
cd ..
phd
pwd
ip a
ip route
nano /etc/network/interfaces
nano /etc/network/interfaces
/etc/init.d/networking restart
ifup enp1s0
reboot
systemctl status apache2
shutdown 0
shutdown 0
lsblk
fdisk /dev/vdc
lsblk
mkfs -t ext4 /dev/vdc1
mkfs -t ext4 /dev/vdc2
lsblk
mkdir /www_dir
mkdir /backup_dir
mount /dev/vdc1 /www_dir/
mount /dev/vdc2 /backup_dir/
nano /etc/fstab 
shutdown 0
cd /www_dir/
ls -ahl
lsblk 
cp /root/Material_Adicional_TPVMCA/index.php .
cp /root/Material_Adicional_TPVMCA/logo.png .
nano /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
ifconfig
nano /etc/apache2/sites-available/000-default.conf 
nano /etc/apache2/apache2.conf 
systemctl restart apache2
shutdown 0
shutdown 0
cat /proc/partitions 
touch /opt/particion
cat /proc/partitions  >> /opt/particion 
cat /opt/particion 
shutdown 0
clear
logout
cd /opt/
ls -ahl
mkdir scripts
nano ./scripts/backup_full.sh
cd ./scripts/


ls -ahl
./backup_full.sh -h
nano ./backup_full.sh 
./backup_full.sh -h
nano ./backup_full.sh 
./backup_full.sh -h
cp --help
nano ./backup_full.sh
./backup_full.sh --help
shutdown 0
