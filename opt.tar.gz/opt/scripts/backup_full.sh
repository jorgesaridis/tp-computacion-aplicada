#! /bin/bash


show_help() {
	cat << EOF
Uso:  backup_full.sh [OPCIÓN] ORIGEN DESTINO
Herramienta para hacer backups de carpetas completas.

Opciones:
  -h, --help Este comando realiza un backup de la carpeta provista en parámetro ORIGEN
             lo comprime en formato tar.gz y lo deja en la carpeta provista en el
             parámetro DESTINO.

EOF
}

hacer_backup() {
	echo "Haciendo backup ..."
	local source="$1"
	local dest="$2"
	backup_name="${dest%/}/${source##*/}_bkp_$(date +%Y%m%d)"
	tar -czvf $backup_name.tar.gz $source
}


if [[ $# -eq 1 ]]; then
	case "$1" in
		-h|--help)
			show_help
			exit 0
			;;
		*)
			echo "Parámetro desconocido" >&2
			exit 1
			;;
	esac
elif [[ $# -eq 2 && -d $1 && -d $2 ]]; then
	hacer_backup $1 $2
	exit 0
else
	echo "Los parámetros provistos no permiten hacer el backup. Revise la ayuda con la opción '-h'" >&2
	exit 1
fi
