cd ./sources.list.d/
ls -ahl
cd ..
shutdown 0
ping www.google.com
apt update
cd /etc/apt
ls -ahl
cat ./sources.list
cp ./sources.list ./sources.list.orig
vi ./sources.list
cat ./sources.list
apt update
cd /var/log/
ls -ahl
cat syslog
cat syslog | grep -i Failed
cat /etc/fstab 
cd /home/
ls
cd /
lsblk 
lsblk --help
cat /etc/fstab 
apt install nano
nano /etc/fstab
clear
logout
nano /etc/fstab
shutdown 0
nano /etc/fstab
nano /etc/fstab
ps -A
ps -A | grep vim
ps -A | grep 552
nano /etc/fstab
cat /etc/fstab 
reboot
cat syslog | grep -i Failed
cat /var/log/syslog | grep -i Failed
lsblk -f
cat /etc/fstab 
journalctl -xeu dev-sdb1.mount
cat /etc/fstab 
nano /etc/fstab 
cat /etc/fstab 
reboot
cat /var/log/syslog | grep -i Failed
cd /home/
ls
cat ./compartido/
cd ./compartido/
ls
cat ./arch1
cat ./arch2
cat ./dir1/
ls -ahl
cat ./hola 
cd ./dir1/
ls -ahl
cd /
apt update
apt upgrade
shutdown 0
apt update && apt install spice-vdagent
reboot
shutdown 0
nano /etc/apt/sources.list
apt update
apt update
nano /etc/apt/sources.list
apt update
nano /etc/apt/sources.list
apt update
apt full-upgrade
apt-get update
apt full-upgrade
reboot
lsb_release -a
cat /etc/debian_version 
apt-cache search openssh-server
apt install openssh-server
apt-cache show openssh-server
apt-cache show openssh-server
ls -ahl
phd
pwd
mkdir material
tar xvf ./Material_Adicional_TPVMCA.tar.gz ./material
ls -ahl
tar -xvzf ./Material_Adicional_TPVMCA.tar.gz -C ./material/
ls -ahl
cd ./material/
ls -ahl
cd ./Material_Adicional_TPVMCA/
ls -ahl
cd ..
cd ..
mv ./material/Material_Adicional_TPVMCA/ .
ls -ahl
cd ./material/
ls
cd ..
rm ./material/
rm -f ./material/
rmdir ./material/
ls -ahl
cd ./Material_Adicional_TPVMCA/
ls -ahl
cat ./clave_privada.txt 
cat ./clave_publica.pub 
cd /
nano /etc/ssh/ssh_config
systemctl enable ssh
systemctl status ssh
nano /etc/ssh/ssh_config
cd /root/Material_Adicional_TPVMCA/
ls -ahl
cat ./clave_privada.txt 
ls -ahl
nano /etc/ssh/ssh_config
systemctl restart ssh
nano /etc/ssh/ssh_config
systemctl restart ssh
shutdown 0
cd /root/
ls -ahl
exit
exit
nano /etc/ssh/ssh_config
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl status ssh
systemctl start ssh
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
cd /
ls -ahl
cd /root/
ls -ahl
stat -c "%a %n" .
stat -c "%a %n" ./.ssh/
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
nano /etc/ssh/ssh_config
nano /etc/ssh/ssh_config
nano /etc/ssh/ssh_config
systemctl stop ssh
systemctl start ssh
cd /var/log/
ls -ahl
cat ./auth.log
ssh root@localhost
nano /etc/ssh/ssh_config
nano /etc/ssh/ssh_config
nano /etc/ssh/sshd_config
systemctl stop ssh
systemctl start ssh
shutdown 0
cd /root/Material_Adicional_TPVMCA/
ls -ahl
shutdown 0
exit
exit
exit
cd /root/.ssh/
ls -ahl
cd ..
ls -ahl
cd ./Material_Adicional_TPVMCA/
ls -ahl
cp ./clave_publica.pub ../.ssh/clave_root.pub
cd ../.ssh/
ls -ahl
ls -ahl
./clave_root.pub >> authorized_keys
cat ./clave_root.pub >> authorized_keys
ls -ahl
cat ./authorized_keys 
cd /etc/ssh/
ls -ahl
nano ./sshd_config
systemctl stop ssh
systemctl start ssh
nano ./sshd_config
systemctl status sshd
systemctl restart sshd
apt update && apt upgrade -y
cd /root/
apt install apache2 apache2-utils -y
apt install php libapache2-mod-php php-mysql -y
systemctl restart apache2
echo "<?php phpinfo(); ?>" | tee /var/www/html/info.php
cd ./Material_Adicional_TPVMCA/
ls -ahl
cp ./index.php /var/www/html/
cp ./logo.png /var/www/html/
cd /var/www/html/
ls -ahl
cat ./index.php 
cd /root/Material_Adicional_TPVMCA/
ls -ahl
cat ./db.sql 
apt install mariadb-server-y
apt install mariadb-server -y
mariadb -u root
systemctl enable mariadb.service
systemctl status mariadb.service
cat ./db.sql 
mariadb -u root
mariadb -u root < ./db.sql 
mariadb -u root
cd ..
cd ..
phd
pwd
ip a
ip route
nano /etc/network/interfaces
nano /etc/network/interfaces
/etc/init.d/networking restart
ifup enp1s0
reboot
systemctl status apache2
shutdown 0
shutdown 0
lsblk
fdisk /dev/vdc
lsblk
mkfs -t ext4 /dev/vdc1
mkfs -t ext4 /dev/vdc2
lsblk
mkdir /www_dir
mkdir /backup_dir
mount /dev/vdc1 /www_dir/
mount /dev/vdc2 /backup_dir/
nano /etc/fstab 
shutdown 0
cd /www_dir/
ls -ahl
lsblk 
cp /root/Material_Adicional_TPVMCA/index.php .
cp /root/Material_Adicional_TPVMCA/logo.png .
nano /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
ifconfig
nano /etc/apache2/sites-available/000-default.conf 
nano /etc/apache2/apache2.conf 
systemctl restart apache2
shutdown 0
shutdown 0
cat /proc/partitions 
touch /opt/particion
cat /proc/partitions  >> /opt/particion 
cat /opt/particion 
shutdown 0
clear
logout
cd /opt/
ls -ahl
mkdir scripts
nano ./scripts/backup_full.sh
cd ./scripts/


ls -ahl
./backup_full.sh -h
nano ./backup_full.sh 
./backup_full.sh -h
nano ./backup_full.sh 
./backup_full.sh -h
cp --help
nano ./backup_full.sh
./backup_full.sh --help
shutdown 0
cd /to_deliver/
ls -ahl
exit
cd /opt/scripts/
ls -ahl
./backup_full.sh -h
nano ./backup_full.sh 
./backup_full.sh -h
nano ./backup_full.sh 
./backup_full.sh -h
nano ./backup_full.sh 
nano ./backup_full.sh 
nano ./backup_full.sh 
nano ./backup_full.sh 
./backup_full.sh -h
nano ./backup_full.sh 
./backup_full.sh -h
./backup_full.sh -h
nano ./backup_full.sh
./backup_full.sh -h
nano ./backup_full.sh
./backup_full.sh -h
./backup_full.sh
nano ./backup_full.sh
./backup_full.sh
./backup_full.sh -h
./backup_full.sh -u
./backup_full.sh --help
./backup_full.sh /opt /var
./backup_full.sh /opt /var /tt
nano ./backup_full.sh
nano ./backup_full.sh
./backup_full.sh /opt /var /tt
./backup_full.sh
./backup_full.sh -h
./backup_full.sh -t
cd /backup_dir/
cat /proc/partitions 
lsblk
cd /opt/scripts/
nano ./backup_full.sh 
./backup_full.sh -h
nano ./backup_full.sh 
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
basename --help
nano ./backup_full.sh 
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
basename /opt/scripts
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
nano ./backup_full.sh 
./backup_full.sh /opt
./backup_full.sh /var/logs
./backup_full.sh /var
./backup_full.sh /var/logs
./backup_full.sh /var/log
./backup_full.sh /www_dir
touch "back_$(date +%Y-%m-%d).log"
ls -ahl
rm ./back_2026-06-11.log 
touch "back_$(date +%Y%m%d).log"
ls -ahl
./backup_full.sh /www_dir
nano ./backup_full.sh 
./backup_full.sh /www_dir
nano ./backup_full.sh 
./backup_full.sh /www_dir
nano ./backup_full.sh 
./backup_full.sh /www_dir
nano ./backup_full.sh 
./backup_full.sh /www_dir
nano ./backup_full.sh 
cd /home/
cd ./compartido/
ls -ahl
cd ./dir1/
ls
cd ~
pwd
ls -ahl
mkdir pruebas
touch ./pruebas/algo.txt
ls ./pruebas/ -ahl
cd /opt/scripts/
./backup_full.sh /root/pruebas 
nano /root/pruebas/algo.txt 
./backup_full.sh /root/pruebas 
nano ./backup_full.sh 
./backup_full.sh /root/pruebas 
tar --usage
./backup_full.sh /root/pruebas 
nano ./backup_full.sh 
./backup_full.sh /root/pruebas 
cd /root/pruebas/
ls -ahl
cd /opt/scripts/
nano ./backup_full.sh 
cd /backup_dir/
ls -ahl
tar -tf ./pruebas_bkp_20260611.tar.gz 
rm ./pruebas_bkp_20260611.tar.gz 
nano /opt/scripts/backup_full.sh 
/opt/scripts/backup_full.sh /root/pruebas
ls -ahl
tar -tf ./pruebas_bkp_20260611.tar.gz 
rm ./pruebas_bkp_20260611.tar.gz 
cd /opt/scripts/
ls -ahl
rm ./back_20260611.log 
nano ./backup_full.sh 
./backup_full.sh /root/pruebas/
./backup_full.sh /root/pruebas
nano ./backup_full.sh 
./backup_full.sh /root/pruebas
nano ./backup_full.sh 
nano ./backup_full.sh 
./backup_full.sh /root/pruebas
nano ./backup_full.sh 
nano ./backup_full.sh 
./backup_full.sh /root/pruebas
tar -tf /backup_dir/pruebas_bkp_20260611.tar.gz 
rm -rf /root/pruebas/
cd /root/
ls -ahl
cd /backup_dir/
ls -ahl
rm ./pruebas_bkp_20260611.tar.gz 
/opt/scripts/
cd /opt/scripts/
nano ./backup_full.sh 
mkdir /root/pruebas
nano /root/pruebas/algo.txt
./backup_full.sh -h
./backup_full.sh -t
./backup_full.sh /root/pruebas1 /backup_dir/
./backup_full.sh /root/pruebas /backup_diri/
./backup_full.sh /root/pruebas /backup_dir/
ls -ahl /backup_dir/
tar -tf /backup_dir/pruebas_bkp_20260611.tar.gz 
nano ./backup_full.sh 
./backup_full.sh /root/pruebas /backup_dir/
nano ./backup_full.sh 
ls -ahl /backup_dir/
rm /backup_dir/pruebas_bkp_20260611.tar.gz 
./backup_full.sh /root/pruebas /backup_dir/
nano ./backup_full.sh 
./backup_full.sh /root/pruebas /backup_dir/
nano ./backup_full.sh 
nano ./backup_full.sh 
./backup_full.sh /root/pruebas /backup_dir/
tar -tf /backup_dir/pruebas_bkp_20260611.tar.gz 
nano ./backup_full.sh 
rm /backup_dir/pruebas_bkp_20260611.tar.gz 
./backup_full.sh /root/pruebas /backup_dir/
tar -tf /backup_dir/pruebas_bkp_20260611.tar.gz 
rm /backup_dir/pruebas_bkp_20260611.tar.gz 
rm -fr /root/pruebas/
systemctl status cron.service
nano /etc/crontab 
nano /etc/crontab 
nano /etc/crontab 
cd /backup_dir/
ls -ahl
ls -ahl
tar -tf ./log_bkp_20260611.tar.gz 
nano /etc/crontab 
ls -ahl
ls -ahl
tar -tf ./www_dir_bkp_20260611.tar.gz 
nano /etc/crontab 
cd /
cat /opt/scripts/backup_full.sh 
cd /
mkdir to_deliver
cd ./to_deliver/
tar -czvf root.tar /root
ls -ahl
tar -czvf etc.tar /etc
ls -ahl
tar -czvf opt.tar /opt/
tar -czvf www_dir.tar /www_dir/
ls -ahl
tar -czvf backup_dir.tar /backup_dir/
ls -ahl
tar -cvzf - /var | split -b 25M - "var.tar.gz.part_"
ls -ahl
ip
ip address
cd ~
shutdown 0
